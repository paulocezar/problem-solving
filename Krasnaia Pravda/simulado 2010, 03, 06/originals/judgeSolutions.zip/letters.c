
/*
Regional Competition 2002, Juniors
Problem LETTERS, Solution in C
*/

#include <stdio.h>

#define INPUT_FILE  "letters.in"
#define OUTPUT_FILE "letters.out"
#define MAX_REDAKA  20
#define MAX_STUPACA 20

int broj_redaka,broj_stupaca;
char ploca[MAX_REDAKA][MAX_STUPACA + 1];
int bilo[26];
int broj_poteza,max_poteza;
FILE *file;

void ucitaj_podatke(void)
{
  int i;

  file = fopen(INPUT_FILE,"r");
  fscanf(file,"%d%d",&broj_redaka,&broj_stupaca);
  for (i = 0;i < broj_redaka;++i)
    fscanf(file,"%s",ploca[i]);
  fclose(file);
}

void rekurzija(int a,int b)
{
  if (a < 0 || a >= broj_redaka || b < 0 || b >= broj_stupaca)
    return;
  if (bilo[ploca[a][b] - 'A'])
    return;

  bilo[ploca[a][b] - 'A'] = 1;
  ++broj_poteza;
  if (broj_poteza > max_poteza)
    max_poteza = broj_poteza;

  rekurzija(a - 1,b);
  rekurzija(a + 1,b);
  rekurzija(a,b - 1);
  rekurzija(a,b + 1);

  bilo[ploca[a][b] - 'A'] = 0;
  --broj_poteza;
}

void rijesi(void)
{
  int i;

  for (i = 0;i < 26;++i)
    bilo[i] = 0;
  broj_poteza = max_poteza = 0;
  rekurzija(0,0);
}

void ispisi_rjesenje(void)
{
  file = fopen(OUTPUT_FILE,"w");
  fprintf(file,"%d\n",max_poteza);
  fclose(file);
}

int main(void)
{
  ucitaj_podatke();
  rijesi();
  ispisi_rjesenje();

  return 0;
}


/*
Regional Competition 2002, Juniors
Problem SONG, Solution in C
*/

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define INPUT_FILE  "song.in"
#define OUTPUT_FILE "song.out"
#define MAX_ZNAKOVA 50

int main(void)
{
  int i,j,k;
  int broj_strofa;
  char stih[MAX_ZNAKOVA + 1],zadnji_slog[4][MAX_ZNAKOVA + 1];
  int pocetak;
  FILE *input_file,*output_file;

  input_file = fopen(INPUT_FILE,"r");
  output_file = fopen(OUTPUT_FILE,"w");
  fscanf(input_file,"%d\n",&broj_strofa);

  for (i = 0;i < broj_strofa;++i)
  {
    for (j = 0;j < 4;++j)
    {
      fscanf(input_file,"%[^\n]\n",stih);
      pocetak = 0;
      for (k = strlen(stih) - 1;k >= 0;--k)
      {
        stih[k] = tolower(stih[k]);
        if (stih[k] == ' ')
        {
          pocetak = k + 1;
          break;
        }
        if (stih[k] == 'a' || stih[k] == 'e' || stih[k] == 'i' ||
            stih[k] == 'o' || stih[k] == 'u')
        {
          pocetak = k;
          break;
        }
      }
      strcpy(zadnji_slog[j],stih + pocetak);
    }

    if (!strcmp(zadnji_slog[0],zadnji_slog[1]) &&
        !strcmp(zadnji_slog[1],zadnji_slog[2]) &&
        !strcmp(zadnji_slog[2],zadnji_slog[3]))
    {
      fprintf(output_file,"savrsena\n");
      continue;
    }
    if (!strcmp(zadnji_slog[0],zadnji_slog[1]) &&
        !strcmp(zadnji_slog[2],zadnji_slog[3]))
    {
      fprintf(output_file,"parna\n");
      continue;
    }
    if (!strcmp(zadnji_slog[0],zadnji_slog[2]) &&
        !strcmp(zadnji_slog[1],zadnji_slog[3]))
    {
      fprintf(output_file,"ukrstena\n");
      continue;
    }
    if (!strcmp(zadnji_slog[0],zadnji_slog[3]) &&
        !strcmp(zadnji_slog[1],zadnji_slog[2]))
    {
      fprintf(output_file,"obgrljena\n");
      continue;
    }
    fprintf(output_file,"slobodan stih\n");
  }

  fclose(input_file);
  fclose(output_file);

  return 0;
}

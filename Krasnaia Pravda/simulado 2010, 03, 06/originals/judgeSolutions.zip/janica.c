
/*
Regional Competition 2002, Juniors
Problem JANICA, Solution in C
*/

#include <stdio.h>

#define INPUT_FILE  "janica.in"
#define OUTPUT_FILE "janica.out"
#define MAX_N 100

int main(void)
{
  int i,j;
  int n,m;
  double vrijeme[MAX_N],najbolje_vrijeme,broj;
  int poredak[MAX_N],temp;
  FILE *file;

  file = fopen(INPUT_FILE,"r");
  fscanf(file,"%d%d",&n,&m);

  fscanf(file,"%lf",&vrijeme[0]);
  najbolje_vrijeme = vrijeme[0];
  for (i = 1;i < n;++i)
  {
    fscanf(file,"%lf",&broj);
    vrijeme[i] = najbolje_vrijeme + broj;
    if (broj < 0)
      najbolje_vrijeme = vrijeme[i];
  }
  for (i = 0;i < n;++i)
    poredak[i] = i;
  for (i = 0;i < n - 1;++i)
    for (j = i + 1;j < n;++j)
      if (vrijeme[poredak[i]] > vrijeme[poredak[j]])
      {
        temp = poredak[i];
        poredak[i] = poredak[j];
        poredak[j] = temp;
      }

  fscanf(file,"%lf",&vrijeme[poredak[m - 1]]);
  najbolje_vrijeme = vrijeme[poredak[m - 1]];
  for (i = m - 2;i >= 0;--i)
  {
    fscanf(file,"%lf",&broj);
    vrijeme[poredak[i]] = najbolje_vrijeme + broj;
    if (broj < 0)
      najbolje_vrijeme = vrijeme[poredak[i]];
  }
  for (i = 0;i < m - 1;++i)
    for (j = i + 1;j < m;++j)
      if (vrijeme[poredak[i]] > vrijeme[poredak[j]])
      {
        temp = poredak[i];
        poredak[i] = poredak[j];
        poredak[j] = temp;
      }

  fclose(file);

  file = fopen(OUTPUT_FILE,"w");
  fprintf(file,"%d\n%d\n%d\n",poredak[0] + 1,poredak[1] + 1,poredak[2] + 1);
  fclose(file);

  return 0;
}

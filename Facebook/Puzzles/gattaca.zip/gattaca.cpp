#include <iostream>
#include <algorithm>
#include <cmath>
#include <fstream>

using namespace std;

struct pred{
  int lo, hi, score;
  bool operator < ( const pred &a ) const {
       return hi < a.hi;
  }
};

int main( int argc, char* argv[] ){

    int t, ct;
    int n, i, j;
    string lixo;
    
    ifstream in( argv[1] );
    ios::sync_with_stdio( false );
    
    in >> n;
    for( i = 0; i < n; i+=80 ) in >> lixo;

    in >> n;
    
    pred predict[n];
    int b[n];
    int dp[n];
    
    for( i = 0; i < n; i++ )
      in >> predict[i].lo >> predict[i].hi >> predict[i].score;
 
    sort( predict, predict+n );
    
    for( i = 0; i < n; i++ ){
      
      for( j = i-1; j >= 0; j-- )
           if( predict[j].hi < predict[i].lo ) break;
      b[i] = j;
      
    }
    
    dp[0] = predict[0].score;
    for( i = 1; i < n; i++ )
      dp[i] = max( ( (b[i]>-1)?(dp[b[i]]):(0) ) + predict[i].score, dp[i-1]  );
    
    cout << dp[n-1] << "\n";

    return 0;
}

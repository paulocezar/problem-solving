#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int n;
bool** can;

int win( int pos ){
	
	for( int i = 0; i < n; i++ ){
		if( can[pos][i] ){
			can[pos][i] = can[i][pos] = false;
			if( !win( i ) ){
				can[pos][i] = can[i][pos] = true;
				return 1;
			}
			can[pos][i] = can[i][pos] = true;
		}
	}
	
	return 0;
	
}

int main( int argc, char* argv[] ){

	int m, a, b;
	
	ifstream in( argv[1] );
    ios::sync_with_stdio( false );
    
	in >> n;
	in >> m;
	
	can = new bool*[n];
	for (int i = 0; i < n; ++i) can[i] = new bool[n];
	
	for( int i = 0; i < n; i++ )
		for( int j = 0; j < n; j++ )
			can[i][j] = true;
	
	for( int i = 0; i < m; i++ ){
		in >> a >> b;
		can[a][b] = can[b][a] = false;
	}
	
	if( m == 0 ) b = 0;
	
	if( win(b) ^ (m & 1) ) cout << "Win\n";
	else cout << "Lose\n";
	
    return 0;
}

#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <list>
#include <algorithm>

using namespace std;

int main( int argc, char *argv[] ){
    
    int n, m;
    string u, v;
    ifstream in(argv[1]);
    list< string >::iterator w;
    
    map< string, list< string > > graph;
    map< string, char > color;
    int total[2];
        
    in >> n;
    while( n-- ){
           in >> u >> m;
           color[u] = -1;
           while( m-- ){
                  in >> v;
                  graph[u].push_back( v );
                  graph[v].push_back( u );
           }
    }

    total[0] = total[1] = 0;
    
    list< string > q;
    q.push_back( u );
    color[u] = 1;
    while( !q.empty() ){
           
           u = q.front(); q.pop_front();
           total[color[u]]++;
           
           for( w = graph[u].begin(); w != graph[u].end(); w++ ){
                if( color[*w] == -1 ){
                    color[*w] = 1-color[u];
                    q.push_back( *w );
                }
           }
           
    }

    if( total[0] > total[1] )
    cout << total[0] << " " << total[1] << "\n";
    else 
    cout << total[1] << " " << total[0] << "\n";
    
    return 0;    
}

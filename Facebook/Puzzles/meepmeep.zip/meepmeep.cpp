#include <fstream>
#include <iostream>

using namespace std;

int main(int argc, char *argv[]) {
  cout << "Meep meep!\n";  
  return 0;
}

#include <iostream>
#include <algorithm>
#include <cmath>
#include <fstream>
#include <vector>
#include <string>

using namespace std;

int main( int argc, char* argv[] ){

    int w, wg, cs;
	string lixo;
	
    ifstream in( argv[1] );
    ios::sync_with_stdio( false );
    
    in >> w;
	int sz = 0;
	
	vector< pair< int, int > > sku;
	
	while( in >> lixo >> wg >> cs ) { sz++; sku.push_back( make_pair( wg, cs ) ); }
	
	int dp[2][w+1];
	dp[0][0] = dp[0][1] = 0;
	
	for( int i = 1; i <= w; i++ ){
		if( i < sku[0].first ) dp[0][i] = sku[0].second;
		else dp[0][i] = dp[0][ i-sku[0].first ] + sku[0].second;
	}
	
	int a = 1, b = 0;
	for( int j = 1; j < sz; j++ ){
	
		for( int i = 1; i <= w; i++ ){
			if( i < sku[j].first ) cs = sku[j].second;
			else cs = dp[a][ i-sku[j].first ] + sku[j].second;
			dp[a][i] = min( dp[b][i], cs );
		}
		a = !a;
		b = !b;
	}
	
		
	cout << dp[b][w] << "\n";

    return 0;
}

#include <iostream>
#include <string>
#include <map>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>

#define DICT "/var/tmp/twl06.txt"

using namespace std;

struct node_t {

	map< char, node_t > sons;
	bool isEnd;

	node_t(){ isEnd = false; }	
		
	map< char, node_t >::iterator beg(){ return sons.begin(); }
	map< char, node_t >::iterator end(){ return sons.end(); }
	
	bool has( char c ){ return (sons.find( c ) != sons.end());  }
	
};

int cost, sz;
string word;

void calc( const vector< int >& last, node_t& node ){

	if( node.isEnd && last[sz] < cost ) cost = last[sz];
	
	int i;
	for( i = 0; i <= sz; i++ ) if( last[i] < cost ) break;
	if( i > sz ) return;
	
	vector< int > row( last.size() );
	row[0] = last[0]+1;
	i = 1;
	
	map< char, node_t >::iterator it;
	for( it = node.beg(); it != node.end(); it++ ){
		for( i = 1; i <= sz; i++ ){
			if( it->first == word[i-1] ) row[i] = last[i-1];
			else row[i] = last[i-1]+1;
			
			row[i] = min( row[i], min( row[i-1]+1, last[i]+1 ) );
		}
		calc( row, it->second );		
	}
	
}

int main( int argc, char* argv[] ){

	ifstream dictin( DICT );
	node_t trie;
	int i, ans;
	
	while( dictin >> word ){
		i = 0;
		node_t* cur = &trie;
		while( cur->has( word[i] ) && i < word.size() ) cur = &cur->sons[ word[i++] ];
		
		while( i < word.size() ) { 
			cur->sons[ word[i] ] = node_t(); 
			cur = &cur->sons[ word[i++] ];
		}
		cur->isEnd = true;		
	}

	ifstream in( argv[1] );
	ans = 0;
	
	while( in >> word ){
		
			cost = 0x3F3F3F3F;
			sz = word.size();
			vector< int > val( sz + 1 );
			
			for( i = 0; i < sz; i++ ){ val[i] = i; word[i] -= 32; }
			val[sz] = sz;
			
			calc( val, trie );
			ans += cost;
			
	}
	
	cout << ans << "\n";

	return 0;
}
